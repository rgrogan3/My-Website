#include "myLib.h"

u16* videoBuffer = (u16*) 0x6000000;

void waitForVblank()
{
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER<160);
}

void delay(int n)
{
	volatile int x = 0;
	for(int i=0; i<5000*n; i++)
	{
		x = x + 1;
	}
}

void setPixel(int row, int col, unsigned short color)
{
	videoBuffer[row * 240 + col] = color;
}


void drawImage3(int row, int col, int width, int height, const u16* image) {
 for(int r = 0; r < height; r++) {
		DMA[3].src = image + width * r;
		DMA[3].dst = videoBuffer + (row + r) * 240 + col;
		DMA[3].cnt = width | DMA_SOURCE_INCREMENT | DMA_DESTINATION_INCREMENT | DMA_ON;
	}
		/*for(int r=0; r<height; r++)
	{
		for(int c=0; c<width; c++)
		{
			setPixel(row+r, col+c, *(image + width * r + c));
		}
		}*/

}

void drawRect(int row, int col, int height, int width, unsigned short color)
{
	for(int r=0; r<height; r++)
	{
		DMA[3].src = &color;
		DMA[3].dst = videoBuffer + (row+r) * 240 + col;
		DMA[3].cnt = width | DMA_SOURCE_FIXED | DMA_ON;
	}
}