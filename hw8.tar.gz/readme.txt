Bill-ger:
This is a re-creation of the game frogger where you Can play as Bill Leahy to try and fill all of your homes!
Here are some general instructions:
1. Begin the game by pressing either START or UP
2. The arrow keys move Bill, don't hit traffic, go off the map or fall in the water!
3. You have 3 lives to start, if your life count drops to 0 you lose
4. You have 30 seconds per life to make it to your home, if you make it you gain a life, if you're not that quick, you lose a life.
5. The home menu can be reched at any time with the select key
I hope you enjoy it!