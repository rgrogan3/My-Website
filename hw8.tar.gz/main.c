#include "billLeahy.h"
#include "myLib.h"
#include "title.h"
#include "text.h"
#include <stdlib.h>
#include <stdio.h>
#include "smartCar.h"
#include "smartBus.h"
#include "gameOver.h"
#include "winner.h"
#include "lilypad.h"
#include "logs.h"

//create obstacle struct
typedef struct {
	int row;
	int col;
	int cdel;
} MOVCAR, MOVBUS, MOVPAD, MOVLOG;

//create frog struct
typedef struct {
	int row;
	int col;
} FROGGY;

int main() {
	REG_DISPCTL = MODE3 | BG2_ENABLE;

	titleScreen();
	while (1);
	return 0;
}

//title screen
void titleScreen() {
	waitForVblank();
	drawImage3(0, 0, TITLE_WIDTH, TITLE_HEIGHT, title);
	while(1) {
		if(KEY_DOWN_NOW(BUTTON_UP)) {
			clearScreen();
			gameScreen();
		}
		if(KEY_DOWN_NOW(BUTTON_START)) {
			clearScreen();
			gameScreen();
		}
	}
}

//clears screen
void clearScreen() {
	waitForVblank();
	u16 white = WHITE;
	DMA[3].src = &white;
	DMA[3].dst = videoBuffer;
	DMA[3].cnt = 38400 | DMA_SOURCE_FIXED | DMA_DESTINATION_INCREMENT | DMA_ON;
	waitForVblank();
}

//loser screen
void youLose() {
	waitForVblank();
	drawImage3(0, 0, GAMEOVER_WIDTH, GAMEOVER_HEIGHT, gameOver);
	while(1) {
		if(KEY_DOWN_NOW(BUTTON_START)) {
			clearScreen();
			gameScreen();
		}
		if(KEY_DOWN_NOW(BUTTON_SELECT)) {
			clearScreen();
			titleScreen();
		}
	}
}

//winner screen
void youWin() {
	waitForVblank();
	drawImage3(0, 0, WINNER_WIDTH, WINNER_HEIGHT, winner);
	while(1) {
		if(KEY_DOWN_NOW(BUTTON_START)) {
			clearScreen();
			gameScreen();
		}
		if(KEY_DOWN_NOW(BUTTON_SELECT)) {
			clearScreen();
			titleScreen();
		}
	}
}

//runs game
void gameScreen() {
	//create lives variable and set aside space
	int lives = 3;
	int oldlives = 3;
	char buffer[14];
	//create timer variable and set aside space
	int timer = 60;
	char buffer2[14];
	int timeLeft = 30; //countdown
	int canMove = 60; //prevent double death when pressing up while dying

	//Set up car structs
	MOVCAR sCars[CARS];
	MOVCAR oldsCars[CARS];
	MOVCAR *carP;
	for(int i = 0; i < CARS / 2; i++) {
		sCars[i].row = 120;
		sCars[i].col = 0 + 60 * i;
		sCars[i].cdel = -1;
		oldsCars[i] = sCars[i];
	}
	for(int i = CARS / 2; i < CARS; i++) {
		sCars[i].row = 100;
		sCars[i].col = 20 + 60 * (i - CARS / 2);
		sCars[i].cdel = -1;
		oldsCars[i] = sCars[i];
	}

	//Set up bus structs
	MOVBUS sBus[BUSSES];
	MOVBUS oldsBus[BUSSES];
	MOVBUS *busP;
	for(int i = 0; i < BUSSES / 2; i++) {
		sBus[i].row = 110;
		sBus[i].col = 0 + 120 * i;
		sBus[i].cdel = 2;
		oldsBus[i] = sBus[i];
	}
	for(int i = BUSSES / 2; i < BUSSES; i++) {
		sBus[i].row = 90;
		sBus[i].col = 40 + 120 * (i - BUSSES / 2);
		sBus[i].cdel = 2;
		oldsBus[i] = sBus[i];
	}

	//set up lilypad structs
	MOVPAD sPad[PADS];
	MOVPAD oldsPad[PADS];
	MOVPAD *padP;
	for(int i = 0; i < PADS / 2; i++) {
		sPad[i].row = 50;
		sPad[i].col = 5 + 60 * i;
		sPad[i].cdel = -10;
		oldsPad[i] = sPad[i];
	}
	for(int i = PADS / 2; i < PADS; i++) {
		sPad[i].row = 30;
		sPad[i].col = 25 + 60 * (i - PADS / 2);
		sPad[i].cdel = -10;
		oldsPad[i] = sPad[i];
	}

	//Set up log structs
	MOVLOG sLog[LOGNUM];
	MOVLOG oldsLog[LOGNUM];
	MOVLOG *logP;
	for(int i = 0; i < LOGNUM / 2; i++) {
		sLog[i].row = 40;
		sLog[i].col = 5 + 120 * i;
		sLog[i].cdel = 10;
		oldsLog[i] = sLog[i];
	}
	for(int i = LOGNUM / 2; i < LOGNUM; i++) {
		sLog[i].row = 20;
		sLog[i].col = 45 + 120 * (i - LOGNUM / 2);
		sLog[i].cdel = 10;
		oldsLog[i] = sLog[i];
	}

	//Set up frog structs
	FROGGY frog;
	FROGGY oldfrog;
	frog.row = 140;
	frog.col = 115;
	oldfrog = frog;

	int size = 10; //height and width of objects (1/2 width of logs/busses)
	int bgcolor = GRAY; //background color of cars/busses
	int state = 0x0; //button pressed state for frog movement
	int fcolor = LIGHTGREEN; //color displaced by froggo
	int oldfcolor = fcolor; //saves color of tile standing on
	int gotHome = 0;
	int isHome = 0x0;
	int padCount = 0;
	int logCount = 0;
	int frogOnPad = 0;
	int frogOnLog = 0;

	//Set up screen background
	//road
	DMA[3].src = &bgcolor;
	DMA[3].dst = videoBuffer + 240 * 90;
	DMA[3].cnt = (38400 - 240 * 90) | DMA_SOURCE_FIXED | DMA_DESTINATION_INCREMENT | DMA_ON;
	//grass
	int lightGreen = LIGHTGREEN;
	DMA[3].src = &lightGreen;
	DMA[3].dst = videoBuffer + 240 * 60;
	DMA[3].cnt = 240 * 30 | DMA_SOURCE_FIXED | DMA_DESTINATION_INCREMENT | DMA_ON;
	//more grass
	DMA[3].src = &lightGreen;
	DMA[3].dst = videoBuffer + 240 * 130;
	DMA[3].cnt = 240 * 30 | DMA_SOURCE_FIXED | DMA_DESTINATION_INCREMENT | DMA_ON;
	//water
	int blue = BLUE;
	DMA[3].src = &blue;
	DMA[3].dst = videoBuffer + 240 * 10;
	DMA[3].cnt = 240 * 50 | DMA_SOURCE_FIXED | DMA_DESTINATION_INCREMENT | DMA_ON;
	//red at top
	int red = RED;
	DMA[3].src = &red;
	DMA[3].dst = videoBuffer;
	DMA[3].cnt = 240 * 10 | DMA_SOURCE_FIXED | DMA_DESTINATION_INCREMENT | DMA_ON;
	//"home" boxes
	for(int i = 1; i < 6; i++) {
		drawRect(10, 5 + 40 * i, 10, 10, DARKGREEN);
	}


	
	//movement loop
	while(1) {
		if(KEY_DOWN_NOW(BUTTON_SELECT)) {
			clearScreen();
			titleScreen();
		}
		//car collision
		for(int i = 0; i < CARS; i++) {
			carP = sCars + i;
			for(int c = 0; c < SMARTCAR_WIDTH; c++) {
				for(int f = 0; f < 2; f++) {
					if((frog.row * 240 + frog.col + 9 * f) == carP -> row * 240 + carP -> col + c) {
						lives--;
						frog.row = 130;
						frog.col = 115;
						fcolor = LIGHTGREEN;
						canMove = 0;
						timeLeft = 30;
					}
				}
			}
		}

		//bus collision
		for(int i = 0; i < BUSSES; i++) {
			busP = sBus + i;
			for(int c = 0; c < SMARTBUS_WIDTH; c++) {
				for(int f = 0; f < 2; f++) {
					if((frog.row * 240 + frog.col + 9 * f) == busP -> row * 240 + busP -> col + c) {
						lives--;
						frog.row = 130;
						frog.col = 115;
						fcolor = LIGHTGREEN;
						canMove = 0;
						timeLeft = 30;
					}
				}
			}
		}

		//edge collision
		if(frog.row < 0 || frog.row >= 160 || frog.col < 0 || frog.col > 230) {
			lives--;
			frog.row = 130;
			frog.col = 115;
			fcolor = LIGHTGREEN;
			frogOnPad = 0;
			frogOnLog = 0;
			timeLeft = 30;
			canMove = 0;
			if(frog.row == 130 || 131) {
				oldfcolor = LIGHTGREEN;
			}
		}

		//got home
		for(int i = 0; i < 5; i++) {
			if(frog.row * 240 + frog.col == 2445 + i * 40) {
				if((1 << i & isHome) == 0) {
					lives++;
					frog.row = 130;
					frog.col = 115;
					fcolor = LIGHTGREEN;
					isHome |= 1 << i;
					canMove = 0;
				}
				gotHome = 1;
			}
		}

		if(lives <= 0) {
			youLose();
		}
		if(isHome == 0x1F) {
			youWin();
		}

		//water collision
		if(!frogOnLog && !frogOnPad) {
			for(int i = 2405; i < 2400 * 6; i += 10) {
				if(frog.row * 240 + frog.col == i) {
					lives--;
					frog.row = 130;
					frog.col = 115;
					fcolor = LIGHTGREEN;
					frogOnPad = 0;
					frogOnLog = 0;
					timeLeft = 30;
					canMove = 0;
				}
			}
		}

		//car movement
		for(int i = 0; i < CARS; i++) {
			carP = sCars + i;
			carP -> col += carP -> cdel;
			if(carP -> col < -10) {
				carP -> col = 229;
			}
		}

		//bus movement
		for(int i = 0; i < BUSSES; i++) {
			busP = sBus + i;
			busP -> col += busP -> cdel;
			if(busP -> col > 239) {
				busP -> col = 0;
			}
		}

		//lilypad movement
		padCount++;
		if(padCount >= 24) {
			for(int i = 0; i < PADS; i++) {
				padP = sPad + i;
				padP -> col += padP -> cdel;
				if(padP -> col < -10) {
					padP -> col = 225;
				}
			}
			padCount = 0;
			if(frogOnPad != 0) {
				frog.row = (sPad + frogOnPad) -> row;
				frog.col = (sPad + frogOnPad) -> col;
				oldfcolor = blue;
			}
		}

		//log movement
		logCount++;
		if(logCount >= 16) {
			for(int i = 0; i < LOGNUM; i++) {
				logP = sLog + i;
				logP -> col += logP -> cdel;
				if(logP -> col > 239) {
					logP -> col = 5;
				}
			}
			logCount = 0;
			if(frogOnLog != 0) {
				if(frogOnLog < LOGNUM) {
					frog.row = (sLog + frogOnLog) -> row;
					frog.col = (sLog + frogOnLog) -> col;
					oldfcolor = blue;
				} else {
					frog.row = (sLog + frogOnLog - LOGNUM) -> row;
					frog.col = (sLog + frogOnLog - LOGNUM) -> col + 10;
					oldfcolor = blue;
				}
			}
		}

		if(canMove >= 60) { //prevent double death
		//frog movement
		if(KEY_DOWN_NOW(BUTTON_UP) && (state & 0x1) == 0) {
			fcolor = videoBuffer[frog.row * 240 + frog.col - 10 * 240];
			frog.row -= 10;
			state |= 0x1;
			frogOnPad = 0;
			frogOnLog = 0;
		}
		if(KEY_DOWN_NOW(BUTTON_DOWN) && (state & 0x2) == 0) {
			fcolor = videoBuffer[frog.row * 240 + frog.col + 10 * 240];
			frog.row += 10;
			state |= 0x2;
			frogOnPad = 0;
			frogOnLog = 0;
		}
		if(KEY_DOWN_NOW(BUTTON_LEFT) && (state & 0x4) == 0) {
			fcolor = videoBuffer[frog.row * 240 + frog.col - 10];
			frog.col -= 10;
			state |= 0x4;
			frogOnPad = 0;
			frogOnLog = 0;
		}
		if(KEY_DOWN_NOW(BUTTON_RIGHT) && (state & 0x8) == 0) {
			fcolor = videoBuffer[frog.row * 240 + frog.col + 10];
			frog.col += 10;
			state |= 0x8;
			frogOnPad = 0;
			frogOnLog = 0;
		}

		if(!KEY_DOWN_NOW(BUTTON_UP)) {
			state &= ~0x1;
		}
		if(!KEY_DOWN_NOW(BUTTON_DOWN)) {
			state &= ~0x2;
		}
		if(!KEY_DOWN_NOW(BUTTON_LEFT)) {
			state &= ~0x4;
		}
		if(!KEY_DOWN_NOW(BUTTON_RIGHT)) {
			state &= ~0x8;
		}
		} else {
			canMove++;
		}

		//check to see if frog is on a pad
		for(int i = 0; i < PADS; i++) {
			padP = sPad + i;
			if(padP -> row == frog.row && padP -> col == frog.col) {
				frogOnPad = i;
			}
		}

		//check to see if frog is on a log
		for(int i = 0; i < LOGNUM; i++) {
			logP = sLog + i;
			if(logP -> row == frog.row && logP -> col == frog.col) {
				frogOnLog = i;
			}
			if(logP -> row == frog.row && logP -> col + 10 == frog.col) {
				frogOnLog = i + LOGNUM;
			}
		}



		// Print the lives remaining to memory (before waitForVblank)
		sprintf(buffer, "Lives: %d", lives);
		//Print time remaining to memory
		if(timer >= 40) {
			timer = 0;
			sprintf(buffer2, "Time: %d", timeLeft);
			timeLeft--;
		}
		timer++;

		if(timeLeft <= 0) {
			lives--;
			frog.row = 130;
			frog.col = 115;
			fcolor = LIGHTGREEN;
			timeLeft = 30;
		}
		waitForVblank();

		//remove previous car image
		for(int i = 0; i < CARS; i++) {	
			drawRect(oldsCars[i].row, oldsCars[i].col, size, size, bgcolor);
		}
		//draw new car image
		for(int i = 0; i < CARS; i++) {
			carP = sCars + i;
			drawImage3(carP -> row, carP -> col, SMARTCAR_WIDTH, SMARTCAR_HEIGHT, smartCar);
			oldsCars[i] = sCars[i];
		}

		//remove previous bus image
		for(int i = 0; i < BUSSES; i++) {	
			drawRect(oldsBus[i].row, oldsBus[i].col, size, size * 2, bgcolor);
		}
		//draw new bus image
		for(int i = 0; i < BUSSES; i++) {
			busP = sBus + i;
			drawImage3(busP -> row, busP -> col, SMARTBUS_WIDTH, SMARTBUS_HEIGHT, smartBus);
			oldsBus[i] = sBus[i];
		}

		//remove previous lilypad image
		for(int i = 0; i < PADS; i++) {	
			drawRect(oldsPad[i].row, oldsPad[i].col, size, size, blue);
		}
		//draw new lilypad image
		for(int i = 0; i < PADS; i++) {
			padP = sPad + i;
			drawImage3(padP -> row, padP -> col, LILYPAD_WIDTH, LILYPAD_HEIGHT, lilypad);
			oldsPad[i] = sPad[i];
		}

		//remove previous log image
		for(int i = 0; i < LOGNUM; i++) {	
			drawRect(oldsLog[i].row, oldsLog[i].col, size, size * 2, blue);
		}
		//draw new log image
		for(int i = 0; i < LOGNUM; i++) {
			logP = sLog + i;
			drawImage3(logP -> row, logP -> col, LOGS_WIDTH, LOGS_HEIGHT, logs);
			oldsLog[i] = sLog[i];
		}

		//remove previous frog image
		if(!gotHome){
			drawRect(oldfrog.row, oldfrog.col, size, size, oldfcolor);
		} else {
			gotHome = 0;
			timeLeft = 30;
			timer = 60;
		}
		//draw new frog image
			drawImage3(frog.row, frog.col, BILLLEAHY_WIDTH, BILLLEAHY_HEIGHT, billLeahy);
			oldfrog = frog;
			oldfcolor = fcolor;

		if(oldlives != lives) {
			drawRect(1,50,8,14*6, RED); //The 14 is allowing for as many as 14 characters
			oldlives = lives;
			canMove = 0;
		}
		drawString(1,50,buffer,GREEN);
		// Erase the old time count
		drawRect(1,140,8,14*6, RED);  // The 14 is allowing for as many as 14 characters
		//Draw new time remaining
		drawString(1,140,buffer2,GREEN);
	}

}






