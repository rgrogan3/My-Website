#ifndef LILYPAD_BITMAP_H
#define LILYPAD_BITMAP_H
extern const unsigned short lilypad[100];
#define LILYPAD_WIDTH 10
#define LILYPAD_HEIGHT 10
#endif