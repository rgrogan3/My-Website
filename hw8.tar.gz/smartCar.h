#ifndef SMARTCAR_BITMAP_H
#define SMARTCAR_BITMAP_H
extern const unsigned short smartCar[100];
#define SMARTCAR_WIDTH 10
#define SMARTCAR_HEIGHT 10
#endif