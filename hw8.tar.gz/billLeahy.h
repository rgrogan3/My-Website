#ifndef BILLLEAHY_BITMAP_H
#define BILLLEAHY_BITMAP_H
extern const unsigned short billLeahy[100];
#define BILLLEAHY_WIDTH 10
#define BILLLEAHY_HEIGHT 10
#endif