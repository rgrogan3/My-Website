#ifndef SMARTBUS_BITMAP_H
#define SMARTBUS_BITMAP_H
extern const unsigned short smartBus[200];
#define SMARTBUS_WIDTH 20
#define SMARTBUS_HEIGHT 10
#endif