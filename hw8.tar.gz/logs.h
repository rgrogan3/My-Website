#ifndef LOGS_BITMAP_H
#define LOGS_BITMAP_H
extern const unsigned short logs[200];
#define LOGS_WIDTH 20
#define LOGS_HEIGHT 10
#endif