# chess

- Fonts:
  - need unicode characters for pieces
  - add unicode encoding to build
- useful things:
  - http://code.makery.ch/blog/javafx-dialogs-official/
- Project requires at least jdk-8u40
  - this is necessary for Alert class (dialog boxes)
  - update jdk: http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
  - proof: https://docs.oracle.com/javase/8/javafx/api/javafx/scene/control/Alert.html
