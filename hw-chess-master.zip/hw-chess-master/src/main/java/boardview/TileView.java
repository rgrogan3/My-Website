package boardview;

import javafx.scene.Node;
import javafx.scene.paint.Color;
import model.Position;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

/**
 * View class for a tile on a chess board
 * A tile should be able to display a chess piece
 * as well as highlight itself during the game.
 *
 * @author <Yourname here>
 */
public class TileView implements Tile {

    private Position position;
    private Label label = new Label("");
    private Rectangle rectangle = new Rectangle(70.0, 70.0, Color.ANTIQUEWHITE);
    private Rectangle rec2 = new Rectangle(70.0, 70.0, Color.TRANSPARENT);
    private StackPane rootNode = new StackPane();


    /**
     * Creates a TileView with a specified position
     * @param p
     */
    public TileView(Position p) {
        position = p;
        rootNode.getChildren().addAll(rectangle, rec2, label);
    }


    @Override
    public Position getPosition() {
        return position;
    }


    @Override
    public Node getRootNode() {
        int temp = (position.getRow() + position.getCol());
        if (temp % 2 == 0) {
            rectangle.setFill(Color.CHARTREUSE);
        }
        return rootNode;
    }

    @Override
    public void setSymbol(String symbol) {
        this.label.setFont(new Font(40.0));
        label.setText(symbol);
    }


    @Override
    public String getSymbol() {
        return label.getText();
    }

    @Override
    public void highlight(Color color) {
        rec2.setFill(color);
        rec2.setOpacity(0.8);
    }

    @Override
    public void clear() {
        rec2.setFill(Color.TRANSPARENT);
    }
}
