package boardview;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import gamecontrol.AIChessController;
import gamecontrol.ChessController;
import gamecontrol.GameController;
import gamecontrol.NetworkedChessController;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.event.ActionEvent;
import javafx.beans.binding.Bindings;


/**
 * Main class for the chess application
 * Sets up the top level of the GUI
 * @author Gustavo
 * @version
 */
public class ChessFX extends Application {

    private GameController controller;
    private BoardView board;
    private Text state;
    private Text sideStatus;
    private VBox root;

    @Override
    public void start(Stage primaryStage) {
        sideStatus = new Text();
        state = new Text("Ongoing");
        Button reset = new Button("Reset");
        reset.setOnAction(new EventHandler<ActionEvent>() {
                @Override public void handle(ActionEvent e) {
                    board.reset(new ChessController());
                }
            });

        Button playComp = new Button("Play Computer");
        playComp.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                board.reset(new AIChessController());
            }
        });

        BorderPane window = new BorderPane();
        TextField ip = new TextField();
        Text myIP = new Text();

        Button host = new Button("Host");
        host.addEventHandler(MouseEvent.MOUSE_CLICKED, makeHostListener());

        Button join = new Button("Join");
        join.addEventHandler(MouseEvent.MOUSE_CLICKED, makeJoinListener(ip));
        join.disableProperty().bind(Bindings.isEmpty(ip.textProperty()));

        try {
            myIP.setText(InetAddress.getLocalHost().toString());
        } catch (UnknownHostException e) {
            myIP.setText("Network Error");
        }

        GameController chess = new ChessController();
        board = new BoardView(chess, state, sideStatus);
        Pane pane = board.getView();
        root = new VBox(10);
        root.getChildren().addAll(pane);

        HBox one = new HBox();
        one.setPadding(new Insets(10.0));
        one.setSpacing(40.0);
        one.getChildren().add(reset);
        one.getChildren().add(playComp);

        HBox two = new HBox();
        two.setPadding(new Insets(10.0));
        two.setSpacing(40.0);
        two.getChildren().add(host);
        two.getChildren().add(myIP);
        two.getChildren().add(join);
        two.getChildren().add(ip);

        HBox three = new HBox();
        three.setPadding(new Insets(10.0));
        three.setSpacing(40.0);
        three.getChildren().add(sideStatus);
        three.getChildren().add(state);

        window.setTop(root);
        window.setCenter(one);
        window.setBottom(two);
        window.setRight(three);
        Scene scene = new Scene(window);
        primaryStage.setScene(scene);
        primaryStage.show();
    }


    private EventHandler<? super MouseEvent> makeHostListener() {
        return event -> {
            board.reset(new NetworkedChessController());
        };
    }

    private EventHandler<? super MouseEvent> makeJoinListener(TextField input) {
        return event -> {
            try {
                InetAddress addr = InetAddress.getByName(input.getText());
                GameController newController
                    = new NetworkedChessController(addr);
                board.reset(newController);
            } catch (IOException e) {
                e.printStackTrace();
            }
        };
    }


    public static void main(String[] args) {
        launch(args);
    }
}
